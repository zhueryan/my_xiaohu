<?php

namespace Illuminate\View;

use Illuminate\Support\HtmlString;

/**
 * @deprecated since version 5.2. Use Illuminate\Support\HtmlString.
 */
class Expression extends HtmlString
{
}
