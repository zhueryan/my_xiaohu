Getting Started
===============

.. toctree::
    :hidden:

    installation
    upgrading
    simple_example

.. include:: map.rst.inc
