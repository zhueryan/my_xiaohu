<?php

namespace Faker\Provider\de_AT;

class Text extends \Faker\Provider\de_DE\Text
{
}
