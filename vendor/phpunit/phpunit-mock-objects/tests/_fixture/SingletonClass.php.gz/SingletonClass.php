<?php

class SingletonClass
{
    public static function getInstance()
    {
    }

    public function doSomething()
    {
    }

    protected function __construct()
    {
    }

    final private function __sleep()
    {
    }

    final private function __wakeup()
    {
    }

    final private function __clone()
    {
    }
}
